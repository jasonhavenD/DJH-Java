package com.main;

import java.util.Scanner;

import com.util.PlaneUtil;

/**
 * 家庭作业的入口
 * 
 * @author christine
 *
 */
public class HomeWork {
	public static void main(String[] args) {
		PlaneUtil.input = PlaneUtil.readFromFile();
		PlaneUtil.records = PlaneUtil.cacuState();
		Scanner scanner = new Scanner(System.in);
		int id;
		while (scanner.hasNext()) {
			id = scanner.nextInt();
			if (-1 == id) {
				System.out.println("exit...");
				return;
			}
			System.out.println(PlaneUtil.judge(id));
		}

	}
}
